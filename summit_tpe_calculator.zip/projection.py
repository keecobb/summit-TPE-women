"""The live transfer calculator. A player's season profile (from the
cache, built once per season by build_cache.py) is static; the target team
and minutes are supplied per call, so the same player can be projected
against many different schools without recomputing her underlying stats
each time.

Adapted from summit_tpe/transfer.py: no pace/tempo term (Teams has no
possessions field), and strength_gap is computed from the EXACT target
team's Current Rating -- not a tier average -- since a coach picks a
specific school, not a tier. strength_gap is expressed in units of the
league's Rat standard deviation (stored in the cache's meta table at
build time) so the production/minutes/hoop-score sensitivity stays
correctly scaled regardless of the actual Rat numbers in a given season.

A team's Current Rating is already opponent-adjusted (it comes out of the
same iterative Off/Def solve as Summit Rat), so it already carries a
strength-of-schedule signal -- that's deliberately the ONLY strength input
here rather than also folding in the Teams sheet's SoS column separately,
which would mostly double-count the same thing.

Calibration note (2nd pass, after review against real cases): the first
version of production_factor/minutes_factor/ts clamps saturated almost
immediately -- by about +/-1.2 standard deviations of strength_gap, which
is a fairly ordinary tier jump, not an extreme one. That meant most
non-trivial transfers were silently returning the clamp boundary instead
of a real computed number. The bounds below are widened so the underlying
formula has room to express itself across the realistic range and only
saturates at the true extremes of this dataset (~+/-3 SD, e.g. a top-15
P5 team vs. one of the very worst low-majors). Anchor point used: Audi
Crooks (Iowa State, elite P5 scorer) projected to Prairie View A&M (one of
the 4 worst-rated teams in the whole 362-team dataset, gap ~-2.96 SD) was
sanity-checked against real-world expectation of a "very good, not
video-game" jump -- roughly 31-34 PPG, not 40 -- which is what pins the
1.30x ceiling below.

These are still hand-picked constants, not fit to real transfer-portal
outcomes (there isn't a labeled dataset of "player X moved from team Y to
team Z and here's what actually happened" to calibrate against) -- treat
any single projection as a reasoned estimate, not a guarantee, especially
near EXTREME_MISMATCH_STD below.
"""

import sqlite3

from summit_calc import clamp

# Bounds on how much a team-strength gap can scale a player's per-40 rates,
# minutes, TS%, and Hoop Score. See calibration note above for how these
# were chosen -- they're intentionally wide enough that a realistic gap
# (roughly up to +/-2.5 SD) produces a genuine computed value rather than
# immediately pinning to the boundary; only the most extreme gaps in this
# dataset (~+/-3 SD or worse) actually saturate them.
PRODUCTION_FACTOR_BOUNDS = (0.55, 1.30)
PRODUCTION_FACTOR_DENOM_STD = 5.0
MINUTES_FACTOR_BOUNDS = (0.50, 1.08)
MINUTES_FACTOR_DENOM_STD = 6.4
HOOPSCORE_SHIFT_BOUNDS = (-10.0, 5.0)
HOOPSCORE_DENOM_STD = 0.8
# TS% has a separate, tighter, physically-motivated ceiling/floor -- unlike
# counting stats, true shooting is bounded by shot mechanics/FT rates, and
# a full-season average above ~80% is essentially unheard of in real
# basketball even against very weak competition.
TS_BOUNDS = (0.20, 0.80)

# |strength_gap| / std beyond which a projection is flagged as an extreme
# mismatch -- not blocked, just labeled, since these are the cases where
# the hand-picked clamps above are most likely doing the work instead of
# the underlying formula, and where real-world outcomes are hardest to
# predict from box-score rate stats alone. Freshmen/sophomores get a
# tighter threshold: their season is a smaller, noisier sample of a still-
# developing player, so the same statistical gap deserves more caution
# sooner. This governs the flag only -- the projected numbers themselves
# are computed identically regardless of class year.
EXTREME_MISMATCH_STD = 2.0
EXTREME_MISMATCH_STD_UNDERCLASS = 1.25
UNDERCLASS_YEARS = {"FR", "SO"}


def _load_meta(conn):
    rows = dict(conn.execute("SELECT key, value FROM meta").fetchall())
    return dict(season=rows["season"], league_mean_rat=float(rows["league_mean_rat"]),
                league_std_rat=float(rows["league_std_rat"]))


def get_player(conn, player_id):
    row = conn.execute("SELECT * FROM players WHERE player_id = ?", (player_id,)).fetchone()
    if row is None:
        return None
    cols = [d[0] for d in conn.execute("SELECT * FROM players LIMIT 0").description]
    return dict(zip(cols, row))


def get_team(conn, team_id):
    row = conn.execute("SELECT * FROM teams WHERE team_id = ?", (team_id,)).fetchone()
    if row is None:
        return None
    cols = [d[0] for d in conn.execute("SELECT * FROM teams LIMIT 0").description]
    return dict(zip(cols, row))


class ProjectionError(ValueError):
    pass


def project_player(conn, player_id, target_team_id, minutes_override=None):
    """Returns a dict with the player's static current profile plus a
    projection at target_team_id. If minutes_override is given (coach
    types in an exact minutes value), it's used AS-IS for the projected
    line instead of the auto-computed minutes factor -- the per-40 rates
    still get the production_factor adjustment for target-team strength,
    but how many minutes she'd play is now the coach's explicit input,
    not a guess.
    """
    player = get_player(conn, player_id)
    if player is None:
        raise ProjectionError(f"No player with id {player_id} in the current-season cache "
                               f"(either unknown, or she didn't meet the minimum-games threshold).")
    target_team = get_team(conn, target_team_id)
    if target_team is None:
        raise ProjectionError(f"No team with id {target_team_id} in the current-season cache.")
    current_team = get_team(conn, player["team_id"])
    if current_team is None:
        raise ProjectionError(f"Player's current team (id {player['team_id']}) isn't in the "
                               f"current-season cache -- can't compute a strength gap.")

    meta = _load_meta(conn)
    std = meta["league_std_rat"]

    strength_gap = target_team["current_rating"] - current_team["current_rating"]
    gap_std = strength_gap / std if std else 0.0

    production_factor = clamp(1.0 - strength_gap / (PRODUCTION_FACTOR_DENOM_STD * std), *PRODUCTION_FACTOR_BOUNDS)
    minutes_factor = clamp(1.0 - strength_gap / (MINUTES_FACTOR_DENOM_STD * std), *MINUTES_FACTOR_BOUNDS)
    hoopscore_shift = clamp(-strength_gap / (HOOPSCORE_DENOM_STD * std), *HOOPSCORE_SHIFT_BOUNDS)

    if minutes_override is not None:
        if minutes_override < 0 or minutes_override > 40:
            raise ProjectionError("minutes_override must be between 0 and 40.")
        proj_minutes = minutes_override
    else:
        proj_minutes = clamp(player["avg_minutes"] * minutes_factor, 4.0, 36.0)

    proj_per40_pts = player["per40_pts"] * production_factor
    proj_per40_reb = player["per40_reb"] * production_factor
    proj_per40_ast = player["per40_ast"] * production_factor
    # Blocks/steals are "production" stats like points/rebounds -- weaker
    # competition means more/easier opportunities to generate them, so they
    # scale the same direction as production_factor.
    proj_per40_blk = player["per40_blk"] * production_factor if player["per40_blk"] is not None else None
    proj_per40_stl = player["per40_stl"] * production_factor if player["per40_stl"] is not None else None
    # Turnovers move the OPPOSITE direction from everything else: a tougher,
    # longer, faster defense forces more turnovers, not fewer, so this is
    # deliberately NOT multiplied by production_factor directly. Mirroring
    # production_factor around 1.0 (2.0 - production_factor) keeps the same
    # bounded, symmetric range (production_factor in [0.55, 1.30] ->
    # tov_factor in [0.70, 1.45]) while pointing the right way: a much
    # stronger target team pushes turnovers up, a much weaker one pulls
    # them down.
    tov_factor = 2.0 - production_factor
    proj_per40_tov = player["per40_tov"] * tov_factor if player["per40_tov"] is not None else None

    proj_ppg = proj_per40_pts * proj_minutes / 40.0
    proj_rpg = proj_per40_reb * proj_minutes / 40.0
    proj_apg = proj_per40_ast * proj_minutes / 40.0
    proj_bpg = proj_per40_blk * proj_minutes / 40.0 if proj_per40_blk is not None else None
    proj_spg = proj_per40_stl * proj_minutes / 40.0 if proj_per40_stl is not None else None
    proj_topg = proj_per40_tov * proj_minutes / 40.0 if proj_per40_tov is not None else None
    proj_ts = clamp(player["ts_pct"] * production_factor, *TS_BOUNDS) if player["ts_pct"] is not None else None
    proj_fg = clamp(player["fg_pct"] * production_factor, *TS_BOUNDS) if player["fg_pct"] is not None else None

    proj_hoop_score = round(clamp(player["hoop_score_raw"] + hoopscore_shift, 30.0, 99.0), 1)

    is_underclass = player["class_year"] in UNDERCLASS_YEARS
    mismatch_threshold = EXTREME_MISMATCH_STD_UNDERCLASS if is_underclass else EXTREME_MISMATCH_STD
    extreme_mismatch = abs(gap_std) >= mismatch_threshold

    confidence = "High" if player["games"] >= 20 else ("Medium" if player["games"] >= 10 else "Low")
    tiers = ["Low", "Medium", "High"]
    if is_underclass:
        # A freshman/sophomore season is a smaller, noisier sample of a
        # still-developing player -- one confidence tier lower than the
        # same games/production would earn an upperclassman.
        confidence = tiers[max(0, tiers.index(confidence) - 1)]
    if extreme_mismatch and confidence == "High":
        # Even a well-sampled upperclassman season doesn't make an extreme
        # strength-gap projection more certain -- that uncertainty comes
        # from the size of the jump, not the size of her sample.
        confidence = "Medium"

    result = dict(
        player=dict(id=player["player_id"], name=player["name"], position=player["position"],
                    class_year=player["class_year"], current_team=current_team["name"],
                    current_division=player["division"], current_tier=current_team["tier"],
                    games=player["games"], season=meta["season"]),
        current=dict(ppg=round(player["ppg"], 1), rpg=round(player["rpg"], 1), apg=round(player["apg"], 1),
                     bpg=round(player["bpg"], 1) if player.get("bpg") is not None else None,
                     spg=round(player["spg"], 1) if player.get("spg") is not None else None,
                     topg=round(player["topg"], 1) if player.get("topg") is not None else None,
                     ts_pct=round(player["ts_pct"] * 100, 1) if player["ts_pct"] is not None else None,
                     fg_pct=round(player["fg_pct"] * 100, 1) if player.get("fg_pct") is not None else None,
                     avg_minutes=round(player["avg_minutes"], 1), hoop_score=player["hoop_score"]),
        target=dict(team=target_team["name"], division=target_team["division"], tier=target_team["tier"],
                    current_rating=round(target_team["current_rating"], 2)),
        minutes_source="coach_override" if minutes_override is not None else "auto_projected",
        projected=dict(
            minutes=round(proj_minutes, 1), ppg=round(proj_ppg, 1), rpg=round(proj_rpg, 1),
            apg=round(proj_apg, 1), bpg=round(proj_bpg, 1) if proj_bpg is not None else None,
            spg=round(proj_spg, 1) if proj_spg is not None else None,
            topg=round(proj_topg, 1) if proj_topg is not None else None,
            ts_pct=round(proj_ts * 100, 1) if proj_ts is not None else None,
            fg_pct=round(proj_fg * 100, 1) if proj_fg is not None else None,
            hoop_score=proj_hoop_score,
        ),
        confidence=confidence,
        strength_gap=round(strength_gap, 2),
        gap_std=round(gap_std, 2),
        extreme_mismatch=extreme_mismatch,
    )
    if extreme_mismatch:
        result["extreme_mismatch_note"] = (
            "Extreme mismatch — projection may be conservative. This target represents an unusually "
            "large strength gap for this player (%.1f standard deviations); treat the exact numbers as "
            "a reasoned estimate, not a precise forecast." % gap_std
        )
    return result


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CLI smoke test for project_player")
    parser.add_argument("--db", default="summit_tpe_cache.sqlite")
    parser.add_argument("--player-id", type=int, required=True)
    parser.add_argument("--target-team-id", type=int, required=True)
    parser.add_argument("--minutes", type=float, default=None)
    args = parser.parse_args()
    conn = sqlite3.connect(args.db)
    import json
    print(json.dumps(project_player(conn, args.player_id, args.target_team_id, args.minutes), indent=2))
