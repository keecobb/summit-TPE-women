# Summit TPE transfer calculator

A player's own season stats (PPG/RPG/APG/TS%/Hoop Score) are static --
computed once per season. What a coach wants is fluid: pick a player, pick
*any* target team, optionally type in exact minutes, get an instant
projection. Same player, run against as many schools as you want. That's
what this is -- not a spreadsheet of precomputed rows (the TransferProjection
scaffold sheet doesn't fit this and can be removed), but a small cache +
live calculator + REST API.

## Setup

```
pip install -r requirements_calculator.txt
```

## 1. Build the cache (once per season, or whenever box scores update)

```
python build_cache.py --path WomensSummitTPE.xlsx --out summit_tpe_cache.sqlite
```

Reads the workbook **read-only** (a few minutes, not the 10+ minutes a
write-mode round trip takes on this file) and writes a small SQLite file
(under 1MB for the current season) with two tables:

- `teams` -- team_id, name, division, conference, **tier**, current_rating, sos
- `players` -- team_id, position, class, season averages (PPG/RPG/APG/BPG/
  SPG/TOPG/TS%/FG%), per-40 rates for points/rebounds/assists/blocks/steals/
  turnovers, Hoop Score, hoop_score_raw -- everyone with >=5 games **and**
  >=100 total minutes in the most recent season found in the Games sheet
  (see "Bug fix" below for why the minutes floor is there)

Re-run this and the API immediately picks up the new file -- no restart
needed for the data, only if you change the code.

## Bug fix: tiny-minute games were distorting per-40 rates

An earlier version computed each player's per-40 rates (points/rebounds/
assists per 40 minutes -- what the projection math scales up or down by
minutes and team strength) by averaging every game's individual per-40
extrapolation. That breaks for very short stints: 3 points in 1 minute
extrapolates to a "120 PPG pace" for that one game, and it was getting
averaged in at full weight. The real case this caught: a player with only
21 total minutes across 7 games (some as short as 1 minute) ranked #1 in
the whole country on the old numbers.

Fixed in `summit_calc.py` / `build_cache.py`: per-40 rates are now season
totals divided by season total minutes (implicitly minutes-weighted)
instead of an average of per-game extrapolations; any single game's
extrapolation is capped at a 4x multiplier; and a 100-total-minutes floor
was added on top of the existing 5-games floor for eligibility. Player
count in the cache dropped from 4,485 to 3,887 as a result (598 excluded
for real but too-brief playing time). Also fixed a related bug in
`api.py`'s `/players` endpoint, which was sorting by the *displayed*
(30-99 clamped) Hoop Score instead of the underlying unclamped value --
several distinct elite seasons legitimately round to the same displayed
99.0, so sorting on the displayed number tied players who weren't actually
tied. If you have an older `summit_tpe_cache.sqlite` or `api.py`, replace
both with the versions in this package and re-run `build_cache.py`.

## 2. Tier classification (as specified)

- **P5** (yes, P5 not P4 -- Big East is counted in with the traditional P4
  since it plays like a power conference in women's hoops): ACC, Big Ten,
  Big 12, SEC, Big East, **plus** Gonzaga, South Dakota State, Princeton,
  and Florida Gulf Coast regardless of their actual conference.
- **Mid-Major**: American, Atlantic 10, Mountain West, WCC, Coastal (CAA),
  Missouri Valley -- minus Gonzaga, which is already in P5 above.
- **Low-Major**: everything else (205 of the 362 teams).

This is a hardcoded, explicit list in `summit_calc.py` (`P5_CONFERENCES`,
`MID_MAJOR_CONFERENCES`, `OUTLIER_P5_PROGRAMS`) -- not derived
statistically, so it won't silently drift as ratings move season to
season. Edit that list directly if a program's status should change.

**Important: tier is a display/filter label only, not part of the math.**
The projection always uses the target team's *exact* Current Rating, not
its tier's average -- confirmed with real data: Gonzaga is tagged "P5" but
its actual rating (17.1) is much closer to a mid-major than to UConn's
(55.0), and projecting a player to Gonzaga vs. UConn produces very
different results, as it should. Tier exists so a coach-facing UI can
filter/group a team picker ("show me Mid-Major schools"), not to average
anything away.

## Calibration update: clamps were saturating too early, extreme-mismatch flag added

Reviewing real projections turned up a second issue, separate from the
per-40 bug above: `projection.py`'s production/minutes/TS clamps were so
tight that most non-trivial transfers were just returning the clamp
boundary instead of a real computed number. Concretely: Audi Crooks (elite
Iowa State scorer) projected to Prairie View A&M (one of the 4 worst-rated
teams in the dataset) only gained +3 PPG despite the enormous gap, and a
freshman bench player from a mediocre low-major projected to a strong P5
program only lost about 1 point on the same minutes -- both suspiciously
flat results, and both turned out to be clamp artifacts (the underlying
formula wanted to move much further in both cases but was capped).

Fixed by widening the bounds (`PRODUCTION_FACTOR_BOUNDS`,
`MINUTES_FACTOR_BOUNDS`, `HOOPSCORE_SHIFT_BOUNDS`, `TS_BOUNDS` at the top
of `projection.py`) so a realistic gap (up to ~2.5 SD) produces a genuine
computed value, and only the most extreme gaps in this dataset (~3 SD,
e.g. a top P5 team vs. one of the very worst low-majors) actually
saturate. Calibration anchor: Crooks -> Prairie View, same minutes, now
projects to ~33.6 PPG, in line with a "very good, not video-game" sanity
check (31-34 PPG) rather than the old +3.

Two new things ride along with this:

- **`extreme_mismatch` flag.** Every `/project` response now includes
  `strength_gap`, `gap_std` (the gap in standard deviations), and
  `extreme_mismatch` (true once `|gap_std|` passes 2.0 -- or 1.25 for
  freshmen/sophomores, since a smaller season sample deserves more
  caution at a smaller gap). When true, an `extreme_mismatch_note` field
  explains it in plain language ("Extreme mismatch — projection may be
  conservative..."). This doesn't change the numbers, it just labels the
  cases where you should treat them as a reasoned estimate rather than a
  precise forecast.
- **Confidence downgrade for underclassmen.** `confidence` (High/Medium/
  Low, previously driven only by games played) now drops one tier for
  FR/SO players, and drops to at most Medium whenever `extreme_mismatch`
  is true, regardless of class year or sample size -- a well-sampled
  junior season doesn't make an extreme strength-gap jump more
  predictable, since that uncertainty comes from the size of the jump
  itself, not from how many games she played. The projected stat numbers
  themselves are still computed identically regardless of class year --
  only the confidence label and mismatch threshold change.

If you have an older `projection.py`, replace it with the version in this
package -- no cache rebuild needed, this only changes how `projection.py`
interprets the same cached per-40 rates.

## Full stat line: blocks, steals, turnovers, FG%

`/project` (and a player's full profile at `/players/{player_id}`) now
include blocks per game, steals per game, turnovers per game, and FG% --
on top of PPG/RPG/APG/TS% that were already there. These come straight
from the same PlayerGameStats columns already being read for the Hoop
Score composite, so no new data source was needed -- `build_cache.py` now
also sums and per-40-rates blk/stl/tov/fgm the same season-totals way as
points/rebounds/assists (see "Bug fix" above for why totals-based, not an
average of per-game rates).

Blocks and steals scale the same direction as points/rebounds in the
projection -- a weaker target team means more/easier opportunities to
generate them, same logic as scoring. **Turnovers are the one stat that
moves the opposite direction on purpose**: a tougher, longer, faster
defense forces more turnovers, not fewer, so turnovers are scaled by
`2.0 - production_factor` instead of `production_factor` directly --
that mirrors the same bounded range around 1.0 but points the right way
(projecting a player up to a much stronger team raises her projected
turnovers; projecting her down to a much weaker one lowers them). You can
see this in the two calibration cases: Audi Crooks's turnovers project to
1.7/game at Prairie View A&M but 3.1/game at UConn, same player, same
minutes, only the target team changed.

If you have an older `summit_tpe_cache.sqlite`, `build_cache.py`,
`projection.py`, or `api.py`, replace all four with the versions in this
package and re-run `build_cache.py` -- the new stat columns won't be in an
old cache file until you do.

## 3. Run the API

```
uvicorn api:app --reload --port 8000
```

Interactive docs at `http://localhost:8000/docs` (auto-generated by
FastAPI -- try requests directly from the browser).

### Endpoints

- `GET /teams?tier=P5&search=&limit=` -- team picker list
- `GET /teams/{team_id}` -- one team's full record
- `GET /players?search=&team_id=&position=&limit=` -- player search/list
- `GET /players/{player_id}` -- one player's full season profile
- `GET /project?player_id=&target_team_id=&minutes=` -- **the calculator**.
  `minutes` is optional -- omit it to get the auto-projected minutes (scaled
  from her current minutes by the strength gap to the target team); pass it
  to override with whatever the coach wants to test.

Example:
```
GET /project?player_id=1546&target_team_id=320
GET /project?player_id=1546&target_team_id=320&minutes=32
```
returns her current static profile, the target team's info, and the
projected line -- run it again with a different `target_team_id` for the
same player to compare schools, which is the whole point.

### CORS

`api.py` currently allows all origins (`allow_origins=["*"]`) so any
site/app can call it during development. Tighten that to your real
domain(s) before this goes anywhere public.

## Validated against the real data

- UConn/South Carolina/Texas/LSU top the P5 ratings; Niagara/Presbyterian/
  Bellarmine bottom out Low-Major -- matches reality.
- Tier counts: P5=83 (79 from the 5 conferences + 4 named outliers exactly),
  Mid-Major=74, Low-Major=205 -- adds up to all 362 teams.
- Same player (Emma Troxell, Abilene Christian) projected to UConn (P5,
  rating 55.0) drops sharply (18.5 min, 4.1 PPG); to Gonzaga (tagged P5 but
  actual rating 17.1, much closer to her own team's 6.9) barely moves
  (27.8 min, 7.9 PPG) -- confirms the math is using each team's real
  rating, not a flattened tier average.
- A minutes override (e.g. 32) replaces the auto-projected minutes exactly
  while still applying the target-team production adjustment to her rates.
- Invalid player/team IDs and out-of-range minutes return clean 404s
  instead of crashing.

## What's still a placeholder (same honesty as the original prototype)

Every constant in the production/minutes/hoop-score sensitivity curves
(the "how much does a stronger team compress her numbers" math) is a
hand-picked, sanity-checked estimate -- widened once (see "Calibration
update" above) against a couple of real spot-checks, but still not fit to
an actual labeled dataset of real transfer outcomes (there isn't one to
calibrate against). There's no pace/tempo adjustment (Teams has no
possessions column). Treat individual projections, especially ones flagged
`extreme_mismatch`, as reasoned estimates rather than precise forecasts,
and revisit the constants again if real transfer-portal outcomes start
looking systematically different from what this predicts.

## Files

- `summit_calc.py` -- shared math (position weights, team ratings, Hoop
  Score scaling, tier classification)
- `build_cache.py` -- run this once per season
- `projection.py` -- the `project_player()` function itself (also runnable
  standalone: `python projection.py --player-id 1546 --target-team-id 320`)
- `api.py` -- the REST layer
- `requirements_calculator.txt`
